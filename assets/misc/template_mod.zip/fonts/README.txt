== DROP YOUR CUSTOM FONTS HERE ==

Fonts can be accessed this way: Paths.font("your font");

To override the base font, create a file named "vcr.ttf".