== DROP YOUR CUSTOM SONGS HERE ==

Example Tree:
└───songs
    └───your-song
        │   Inst.ogg
        │   Voices.ogg

You can also set custom instrumentals and voices for custom difficulties by naming them this way:
Inst-difficulty.ogg
Voices-difficulty.ogg