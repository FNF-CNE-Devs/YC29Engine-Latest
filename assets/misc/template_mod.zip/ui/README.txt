== DROP YOUR CUSTOM UI SCRIPTS HERE ==

This allows you to "inject" code into states such as the Main Menu.

To do so, just create a file named like the state (ex: MainMenuState.hx), then your script will be loaded in whenever you enter that state.